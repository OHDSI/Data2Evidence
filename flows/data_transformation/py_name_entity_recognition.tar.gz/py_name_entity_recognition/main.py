from pydantic import BaseModel, Field
from typing import List
import asyncio
from py_name_entity_recognition import extract_entities
from py_name_entity_recognition.models.config import ModelConfig
from dotenv import load_dotenv
import os, json
from py_name_entity_recognition.core.engine import CoreEngine
from py_name_entity_recognition.models.factory import ModelFactory
from py_name_entity_recognition.observability.visualization import display_biores
from langchain_core.language_models import BaseLanguageModel
from py_name_entity_recognition.utils.biores_converter import BIOSESConverter
from py_name_entity_recognition.data_handling.merging import ChunkMerger
import spacy

load_dotenv()
class CustomEngine(CoreEngine):
    def __init__(
        self, 
        nlp,        
        model: BaseLanguageModel,
        schema: type[BaseModel],
        max_retries: int = 3,
        chunk_size: int = 2000,
        chunk_overlap: int = 300,):
        super().__init__(
            model=model,
            schema=schema,
            max_retries=max_retries,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,)
        self.nlp = nlp
        self.biores_converter = BIOSESConverter(self.nlp)
        self.merger = ChunkMerger(self.nlp)
        

class UserInfo(BaseModel):
    """Schema for extracting user information."""
    Medication: List[str] = Field(description="Names of medications mentioned.")
    Condition: List[str] = Field(description="Medical conditions, diagnoses, or symptoms.")
    SubstanceUse: List[str] = Field(description="Substances used, such as alcohol or tobacco.")
    Procedure: List[str] = Field(description="Medical procedures or interventions.")
    Formulation: List[str] = Field(description="Medication formulations, e.g., powder, solution, injection.")
    Frequency: List[str] = Field(description="Frequency of medication administration, e.g., BID, TID.")
    Dosage: List[str] = Field(description="Dosages of medications, e.g., 500 mg, 5,000 unit/mL.")
    Route: List[str] = Field(description="Routes of medication administration, e.g., oral, topical, injection.")
    Duration: List[str] = Field(description="Duration of medication use or treatment.")

    
text = f"""
        Admission Date:  [**2573-5-30**]              Discharge Date:   [**2573-7-1**]
        
        Date of Birth:  [**2498-8-19**]             Sex:   F
        
        Service: SURGERY
        
        Allergies:
        Hydrochlorothiazide
        
        Attending:[**First Name3 (LF) 1893**]
        Chief Complaint:
        Abdominal pain
        
        Major Surgical or Invasive Procedure:
        PICC line [**6-25**]
        ERCP w/ sphincterotomy [**5-31**]
        
        
        History of Present Illness:
        74y female with type 2 dm and a recent stroke affecting her
        speech, who presents with 2 days of abdominal pain. Imaging shows no evidence of metastasis. She is not receiving any chemo.
        
        Past Medical History:
        1. Colon cancer dx'd in [**2554**], tx'd with hemicolectomy, XRT,
        chemo. Last colonoscopy showed: Last CEA was in the 8 range
        (down from 9)
        2. Type II Diabetes Mellitus
        3. Hypertension
        
        Social History:
        Married, former tobacco use. No alcohol or drug use.
        
        Family History:
        Mother with stroke at age 82. no early deaths.
        2 daughters- healthy
        
        
        Brief Hospital Course:
        Ms. [**Known patient lastname 2004**] was admitted on [**2573-5-30**]. Ultrasound at the time of
        admission demonstrated pancreatic duct dilitation and an
        edematous gallbladder. She was admitted to the ICU.
        Discharge Medications:
        1. Miconazole Nitrate 2 % Powder Sig: One (1) Appl Topical  BID
        (2 times a day) as needed.
        2. Heparin Sodium (Porcine) 5,000 unit/mL Solution Sig: One (1)
        Injection TID (3 times a day).
        3. Acetaminophen 160 mg/5 mL Elixir Sig: One (1)  PO Q4-6H
        (every 4 to 6 hours) as needed.
        
        Discharge Diagnosis:
        Type 2 DM
        Pancreatitis
        HTN
        h/o aspiration respiratory distress
        
        
        Discharge Instructions:
        Patient may shower. Please call your surgeon or return to the
        emergency room if [**Doctor First Name **] experience fever >101.5, nausea, vomiting,
        abdominal pain, shortness of breath, abdominal pain or any
        significant  change in your medical condition. A
        
        Completed by: [**First Name11 (Name Pattern1) 2010**] [**Last Name (NamePattern1) 2011**] MD [**MD Number 2012**] [**2573-7-1**] @ 1404
        Signed electronically by: DR. [**First Name8 (NamePattern2) **] [**Last Name (NamePattern1) **]
         on: FRI [**2573-7-2**] 8:03 AM
        (End of Report)
    """

azure_config = ModelConfig(
                        provider = 'azure',
                        model_name = 'gpt-4o',
                        azure_deployment = os.getenv('AZURE_OPENAI_API_DEPLOYMENT_NAME'),
                        azure_endpoint = os.getenv('AZURE_OPENAI_API_ENDPOINT'),
                        azure_api_version = os.getenv('AZURE_OPENAI_API_VERSION'),
                        max_tokens=200,
                        top_p=0.8,
                    )

# Run the async extraction function
async def main():
    lcel_output = await extract_entities(
        input_data=text,
        schema=UserInfo,
        model_config=azure_config,
        output_format="json"
    )
    print('lcel_output', lcel_output)
    lcel_path = 'output_lcel.json'
    with open(lcel_path, 'w') as f:
        json.dump(lcel_output, f)
        
    agentic_output = await extract_entities(
        input_data=text,
        schema=UserInfo,
        model_config=azure_config,
        # output_format="json",
        mode="agentic"
    )
    # print('agentic_output',agentic_output)
    # agentic_path = 'output_agentic.json'
    # with open(agentic_path, 'w') as f:
    #     json.dump(agentic_output, f)
        
    display_biores(agentic_output)
        
async def custom(model_name=None):
    nlp = spacy.load(model_name)
    engine = CustomEngine(
        model=ModelFactory.create(azure_config), # Default OpenAI model
        schema=UserInfo,
        nlp=nlp, # Default spaCy model
        )
    custom_output = await engine.run(text, mode="agentic")
    print('custom_output', custom_output)
    # display_biores(custom_output)

if __name__ == "__main__":
    asyncio.run(main())
    # asyncio.run(custom('en_ner_bc5cdr_md'))
    # asyncio.run(custom('en_core_web_sm'))